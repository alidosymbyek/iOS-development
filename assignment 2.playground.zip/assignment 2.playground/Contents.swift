import UIKit

var greeting = "Hello, playground"
var fruits = ["apple","banana","cherry","orange","pineapple"]
var set: Set<Int> = [1,2,3,4,5]
set.insert(6)
print(set)
var languagesAndReleasedate:Dictionary<String,Int> = ["C":1972,"C++":1985,"Java":1995,"Python":1991]
var colors = ["red", "blue", "green","purple"]
colors[1] = "yellow"
print(colors)
var first:Set<Int> = [1,2,3,4]
var second:Set<Int> = [3,4,5,6]
print(first.intersection(second))
var studentsAndscores :Dictionary<String,Int> = ["Alice":100,"Bob":90,"CJ":80]
studentsAndscores["Bob"] = 999
print(studentsAndscores)

var fruits1 = ["appple","banana"]
var fruits2 = ["cherry", "date"]

let fruits3 = fruits1 + fruits2
print(fruits3)
var countries :Dictionary <String,Int> = ["Kazakhstan":1991,"China":1971,"India":1947]
countries["Rwanda"] = 1990
print(countries)
let set1 :Set<String> = ["cat","dog"]
let set2 :Set<String> = ["dog","mouse"]
let set3 = set1.union(set2)
print(set3.subtracting(set2))
let grades :Dictionary<String,Array> = ["Alice":[1,2,3],"Bob":[2,3,4]]
//print(grades.values[1])
print(grades["Bob"])

