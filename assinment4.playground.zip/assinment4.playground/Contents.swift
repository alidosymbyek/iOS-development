
func fields(_ line: String, separatedBy separator: Character = ":") -> [String] {
    var result: [String] = []
    var current = ""
    for character in line {
        if character == separator {
            result.append(current)
            current = ""
        } else {
            current.append(character)
        }
    }
    result.append(current)
    return result
}

/// Cargo manifest as recovered from the damaged recorder.
let rawManifest = [
    "crate:101:120",
    "container:KZ-ALM-7:340",
    "livestock:lab mice:12:2",
    "???-corrupted-line",
    "crate:102:75",
    "container:KZ-ALM-9:410",
    "livestock:ficus:3:5",
    "crate:103:260",
    "crate:104:abc",
    ""
]

/// Oxygen readings. One of these deck names is not a real deck.
let deckReadings: [(deck: String, oxygen: Int)] = [
    (deck: "bridge",     oxygen: 78),
    (deck: "lab",        oxygen: 64),
    (deck: "greenhouse", oxygen: 55),
    (deck: "cargo",      oxygen: 12),
    (deck: "medbay",     oxygen: 90),
    (deck: "engine",     oxygen: 41)
]

/// Crew records, straight from the personnel file.
let crewData: [(name: String, deck: String, oxygen: Int)] = [
    (name: "Timur",   deck: "engine", oxygen: 62),
    (name: "Dana",    deck: "lab",    oxygen: 48),
    (name: "Aigerim", deck: "bridge", oxygen: 91),
    (name: "Nurlan",  deck: "cargo",  oxygen: 17)
]

print("ALMA-7 recorder online: \(rawManifest.count) manifest lines, \(deckReadings.count) readings, \(crewData.count) crew records.")
enum Deck: String, CaseIterable {
    case bridge
    case lab
    case cargo
    case medbay
    case engine

    var evacuationPriority: Int {
        switch self {
        case .bridge:
            return 1
        case .medbay:
            return 2
        case .lab:
            return 3
        case .engine:
            return 4
        case .cargo:
            return 5
        }
    }
}

print("\n--- Level 1.1: Deck register ---")
for deck in Deck.allCases {
    print("Deck \(deck.rawValue) -> evacuation priority \(deck.evacuationPriority)")
}

// 1.2
enum AlarmLevel: Int {
    case green = 0
    case yellow
    case orange
    case red

    static func level(forTotalMass mass: Int) -> AlarmLevel {
        let step = min(max(mass / 500, 0), 3)
        return AlarmLevel(rawValue: step) ?? .red
    }
}

print("Alarm for 0 kg: \(AlarmLevel.level(forTotalMass: 0))")
print("Alarm for 940 kg: \(AlarmLevel.level(forTotalMass: 940))")
print("Alarm for 4000 kg: \(AlarmLevel.level(forTotalMass: 4000))")


// MARK: Level 2 · The Manifest

// 2.1
enum ManifestEntry {
    case crate(id: Int, massKg: Int)
    case container(code: String, massKg: Int)
    case livestock(species: String, count: Int, massPerUnitKg: Int)
    case unknown(raw: String)
}

// 2.2
func parseEntry(_ line: String) -> ManifestEntry {
    let parts = fields(line)

    guard let tag = parts.first else {
        return .unknown(raw: line)
    }

    switch tag {
    case "crate":
        guard parts.count == 3,
              let id = Int(parts[1]),
              let massKg = Int(parts[2]) else {
            return .unknown(raw: line)
        }
        return .crate(id: id, massKg: massKg)

    case "container":
        guard parts.count == 3,
              let massKg = Int(parts[2]) else {
            return .unknown(raw: line)
        }
        return .container(code: parts[1], massKg: massKg)

    case "livestock":
        guard parts.count == 4,
              let count = Int(parts[2]),
              let massPerUnitKg = Int(parts[3]) else {
            return .unknown(raw: line)
        }
        return .livestock(
            species: parts[1],
            count: count,
            massPerUnitKg: massPerUnitKg
        )

    default:
        return .unknown(raw: line)
    }
}

// 2.3
func mass(of entry: ManifestEntry) -> Int {
    switch entry {
    case .crate(_, let massKg):
        return massKg
    case .container(_, let massKg):
        return massKg
    case .livestock(_, let count, let massPerUnitKg):
        return count * massPerUnitKg
    case .unknown:
        return 0
    }
}

var parsedManifest: [ManifestEntry] = []
var manifestTotalMass = 0
var unknownManifestCount = 0

for line in rawManifest {
    let entry = parseEntry(line)
    parsedManifest.append(entry)
    manifestTotalMass += mass(of: entry)

    if case .unknown = entry {
        unknownManifestCount += 1
    }
}

let A = manifestTotalMass

print("\n--- Level 2: Manifest ---")
print("Total manifest mass: \(A) kg")
print("Unknown manifest lines: \(unknownManifestCount)")


// MARK: Level 3 · Crew Snapshots

// 3.1
struct CrewSnapshot {
    let name: String
    var deck: Deck
    var oxygen: Int

    mutating func breathe(_ amount: Int) {
        oxygen = max(0, oxygen - amount)
    }

    mutating func move(to deck: Deck) {
        self.deck = deck
    }

    mutating func reviveInMedbay() {
        self = CrewSnapshot(name: name, deck: .medbay, oxygen: 100)
    }

    static func rookie(named name: String) -> CrewSnapshot {
        CrewSnapshot(name: name, deck: .bridge, oxygen: 100)
    }
}

// CrewSnapshot receives the memberwise initializer automatically because it is a struct
// whose stored properties have no custom initializer. TeleportPod is a class, so we write init ourselves.

// 3.2
let crewRoster: [CrewSnapshot] = {
    var roster: [CrewSnapshot] = []

    for record in crewData {
        if let deck = Deck(rawValue: record.deck) {
            roster.append(
                CrewSnapshot(name: record.name, deck: deck, oxygen: record.oxygen)
            )
        } else {
            print("WARNING: unknown deck '\(record.deck)' for \(record.name). Record skipped.")
        }
    }

    return roster
}()

print("\n--- Level 3.2: Crew roster ---")
print("Crew members loaded: \(crewRoster.count)")
if let firstCrew = crewRoster.first {
    print("First crew member: \(firstCrew.name), deck: \(firstCrew.deck.rawValue), oxygen: \(firstCrew.oxygen)")
}

// 3.3 · Value-semantics demonstration (copy / plain parameter / inout)
func changeSnapshotPlain(_ snapshot: CrewSnapshot) {
    var localCopy = snapshot
    localCopy.breathe(10)
    print("Inside plain function: \(localCopy.name) oxygen = \(localCopy.oxygen)")
}

func changeSnapshotInout(_ snapshot: inout CrewSnapshot) {
    snapshot.breathe(10)
}

print("\n--- Level 3.3: Value semantics ---")
if let firstCrew = crewRoster.first {
    var original = firstCrew
    var copied = original

    print("Copy test BEFORE: original = \(original.oxygen), copy = \(copied.oxygen)")
    copied.breathe(7)
    print("Copy test AFTER:  original = \(original.oxygen), copy = \(copied.oxygen)")

    print("Plain parameter BEFORE: original = \(original.oxygen)")
    changeSnapshotPlain(original)
    print("Plain parameter AFTER:  original = \(original.oxygen)")

    print("inout BEFORE: original = \(original.oxygen)")
    changeSnapshotInout(&original)
    print("inout AFTER:  original = \(original.oxygen)")

    original.reviveInMedbay()
    print("reviveInMedbay: \(original.name), deck = \(original.deck.rawValue), oxygen = \(original.oxygen)")
}


// MARK: Level 4 · The Teleport Pod

// 4.1
final class TeleportPod {
    let id: String
    var chargeLevel: Int
    var occupant: CrewSnapshot?

    init(id: String, chargeLevel: Int) {
        self.id = id
        self.chargeLevel = chargeLevel
        self.occupant = nil
    }

    func load(_ crew: CrewSnapshot) -> Bool {
        if occupant != nil || chargeLevel < 20 {
            return false
        }

        occupant = crew
        return true
    }

    func fire() -> CrewSnapshot? {
        guard let currentOccupant = occupant else {
            return nil
        }

        chargeLevel -= 20
        occupant = nil
        return currentOccupant
    }

    // Bonus: this runs when the last strong reference to the pod disappears.
    deinit {
        print("deinit TeleportPod \(id)")
    }
}

func crew(named name: String, in roster: [CrewSnapshot]) -> CrewSnapshot? {
    for member in roster {
        if member.name == name {
            return member
        }
    }
    return nil
}

// 4.2 · Charge ledger: load+fire three times, then fire an empty pod
let podP1 = TeleportPod(id: "P-1", chargeLevel: 100)

print("\n--- Level 4.2: Charge ledger ---")
if let timur = crew(named: "Timur", in: crewRoster) {
    print("Load Timur: \(podP1.load(timur)); charge = \(podP1.chargeLevel)")
    let fired = podP1.fire()
    print("Fire Timur: \(fired?.name ?? "none"); charge = \(podP1.chargeLevel)")
}

if let dana = crew(named: "Dana", in: crewRoster) {
    print("Load Dana: \(podP1.load(dana)); charge = \(podP1.chargeLevel)")
    let fired = podP1.fire()
    print("Fire Dana: \(fired?.name ?? "none"); charge = \(podP1.chargeLevel)")
}

if let nurlan = crew(named: "Nurlan", in: crewRoster) {
    print("Load Nurlan: \(podP1.load(nurlan)); charge = \(podP1.chargeLevel)")
    let fired = podP1.fire()
    print("Fire Nurlan: \(fired?.name ?? "none"); charge = \(podP1.chargeLevel)")
}

let emptyFire = podP1.fire()
print("Fire empty pod: \(emptyFire?.name ?? "none"); charge = \(podP1.chargeLevel)")

let C = podP1.chargeLevel

// 4.3 · Reference-semantics demonstration
print("\n--- Level 4.3: Reference semantics ---")
let referencePodA = TeleportPod(id: "REF", chargeLevel: 90)
let referencePodB = referencePodA
print("Pod reference BEFORE: A = \(referencePodA.chargeLevel), B = \(referencePodB.chargeLevel)")
referencePodB.chargeLevel = 35
print("Pod reference AFTER:  A = \(referencePodA.chargeLevel), B = \(referencePodB.chargeLevel)")

var snapshotA = CrewSnapshot.rookie(named: "Reference Test")
var snapshotB = snapshotA
print("Struct copy BEFORE: A = \(snapshotA.oxygen), B = \(snapshotB.oxygen)")
snapshotB.oxygen = 35
print("Struct copy AFTER:  A = \(snapshotA.oxygen), B = \(snapshotB.oxygen)")
// Rule: assigning a struct copies its value, while assigning a class copies a reference to the same object.


// MARK: Level 5 · Station Systems

// 5.1
final class Station {
    let callSign: String

    var hullIntegrity: Int {
        willSet {
            print("Hull integrity transition: \(hullIntegrity) -> \(newValue)")
        }
        didSet {
            if hullIntegrity > 100 {
                hullIntegrity = 100
            } else if hullIntegrity < 0 {
                hullIntegrity = 0
            }
        }
    }

    var oxygenByDeck: [Deck: Int]

    lazy var fullDiagnostics: String = {
        print("Running full scan...")
        return "Station \(callSign): hull=\(hullIntegrity), totalOxygen=\(totalOxygen), averageOxygen=\(averageOxygen)"
    }()

    var totalOxygen: Int {
        var total = 0
        for value in oxygenByDeck.values {
            total += value
        }
        return total
    }

    var averageOxygen: Int {
        get {
            if oxygenByDeck.isEmpty {
                return 0
            }
            return totalOxygen / oxygenByDeck.count
        }
        set {
            var decks: [Deck] = []
            for deck in oxygenByDeck.keys {
                decks.append(deck)
            }

            for deck in decks {
                oxygenByDeck[deck] = newValue
            }
        }
    }

    init(callSign: String, hullIntegrity: Int, readings: [(deck: String, oxygen: Int)]) {
        self.callSign = callSign
        self.hullIntegrity = hullIntegrity

        var validReadings: [Deck: Int] = [:]
        for reading in readings {
            if let deck = Deck(rawValue: reading.deck) {
                validReadings[deck] = reading.oxygen
            } else {
                print("WARNING: invalid deck reading '\(reading.deck)' skipped.")
            }
        }
        self.oxygenByDeck = validReadings
    }
}

let station = Station(callSign: "ALMA-7", hullIntegrity: 88, readings: deckReadings)
let B = station.averageOxygen

print("\n--- Level 5.1: Station systems ---")
print("Starting total oxygen: \(station.totalOxygen)")
print("Starting average oxygen (B): \(B)")

print("First diagnostics access: \(station.fullDiagnostics)")
print("Second diagnostics access: \(station.fullDiagnostics)")

let untouchedStation = Station(callSign: "ALMA-7-BACKUP", hullIntegrity: 70, readings: deckReadings)
print("Created \(untouchedStation.callSign); fullDiagnostics was not accessed, so its scan did not run.")
print("Backup station average oxygen: \(untouchedStation.averageOxygen)")

// Demonstrate the computed setter after B has already been captured.
station.averageOxygen = 60
print("After setting averageOxygen to 60: average = \(station.averageOxygen), total = \(station.totalOxygen)")

// 5.2 · The clamp trap: 130, then -40, then 55
print("\n--- Level 5.2: Clamp trap ---")
station.hullIntegrity = 130
print("After assigning 130: \(station.hullIntegrity)")

station.hullIntegrity = -40
print("After assigning -40: \(station.hullIntegrity)")

station.hullIntegrity = 55
print("After assigning 55: \(station.hullIntegrity)")

// Assigning hullIntegrity inside its own didSet does not call the observer again,
// so clamping the value there does not create an infinite loop.


// MARK: Level 6 · Incident Reports
// For each report: expectation, actual behaviour, language rule, and fixed version.

print("\n--- Level 6: Incident Reports ---")

// Report 1
// Expected: every member in roster loses 10 oxygen.
// Actual: `member` is a separate struct copy for each loop iteration, so `roster` stays unchanged.
// Rule: CrewSnapshot is a value type; `for var member in roster` mutates only the local copy.
// Fix: mutate the array element itself by index.
var report1Roster = crewRoster
print("Report 1 BEFORE: first oxygen = \(report1Roster.first?.oxygen ?? -1)")
var report1Index = 0
while report1Index < report1Roster.count {
    report1Roster[report1Index].breathe(10)
    report1Index += 1
}
print("Report 1 AFTER: first oxygen = \(report1Roster.first?.oxygen ?? -1)")

// Report 2
// Expected: podA stays at charge 100 after podB changes.
// Actual: podA and podB are references to the same TeleportPod object, so both show 0.
// Rule: classes have reference semantics.
// Fix: create a second TeleportPod instance if independent state is required.
let report2PodA = TeleportPod(id: "A", chargeLevel: 100)
let report2PodB = TeleportPod(id: "A-copy", chargeLevel: report2PodA.chargeLevel)
print("Report 2 BEFORE: podA = \(report2PodA.chargeLevel), podB = \(report2PodB.chargeLevel)")
report2PodB.chargeLevel = 0
print("Report 2 AFTER: podA = \(report2PodA.chargeLevel), podB = \(report2PodB.chargeLevel)")

// Report 3
// Expected: add(_:) appends a new string to entries.
// Actual in the original code: it does not compile because a non-mutating struct method cannot change stored state.
// Rule: a struct instance method that changes self or a stored property must be marked `mutating`.
// Fix:
struct Logbook {
    var entries: [String] = []

    mutating func add(_ entry: String) {
        entries.append(entry)
    }
}

var report3Logbook = Logbook()
print("Report 3 BEFORE: entries = \(report3Logbook.entries.count)")
report3Logbook.add("Teleporter checked")
print("Report 3 AFTER: entries = \(report3Logbook.entries.count)")

// Report 4
// Original:
// let snapshot = CrewSnapshot.rookie(named: "Dana")
// snapshot.oxygen = 40
// let pod = TeleportPod(id: "B", chargeLevel: 50)
// pod.chargeLevel = 10
//
// Expected: both assignments are allowed because both properties are declared with var.
// Actual: snapshot.oxygen = 40 is a compile error, while pod.chargeLevel = 10 is allowed.
// Rule: `let` on a struct freezes the entire value. `let` on a class freezes only the reference,
//       so mutable properties of the referenced object can still change.
// Fix for the struct: declare the snapshot with var.
var report4Snapshot = CrewSnapshot.rookie(named: "Dana")
print("Report 4 struct BEFORE: oxygen = \(report4Snapshot.oxygen)")
report4Snapshot.oxygen = 40
print("Report 4 struct AFTER: oxygen = \(report4Snapshot.oxygen)")

let report4Pod = TeleportPod(id: "B", chargeLevel: 50)
print("Report 4 class BEFORE: charge = \(report4Pod.chargeLevel)")
report4Pod.chargeLevel = 10
print("Report 4 class AFTER: charge = \(report4Pod.chargeLevel)")


// MARK: Level 7 · Sealing the Black Box

final class FlightRecorder {
    // `private` blocks all direct access to the stored entry list from outside this type.
    private var entries: [String] = []

    // `private(set)` blocks outside code from changing the sealed state directly.
    private(set) var isSealed = false

    var entryCount: Int {
        entries.count
    }

    var transcript: String {
        if entries.isEmpty {
            return "(empty)"
        }

        var text = ""
        var index = 0
        while index < entries.count {
            text += "\(index + 1). \(entries[index])"
            if index + 1 < entries.count {
                text += "\n"
            }
            index += 1
        }
        return text
    }

    func add(_ entry: String) -> Bool {
        if isSealed {
            return false
        }

        entries.append(entry)
        return true
    }

    func seal() {
        isSealed = true
    }

    // `fileprivate` blocks other files, but allows the audit free function in this file to read a safe copy.
    fileprivate func auditEntries() -> [String] {
        entries
    }
}
func auditTranscript(of recorder: FlightRecorder) -> String {
    let entries = recorder.auditEntries()
    var result = "AUDIT"

    for entry in entries {
        result += "\n- \(entry)"
    }

    return result
}

print("\n--- Level 7: Flight recorder ---")
let recorder = FlightRecorder()
print("Add first entry: \(recorder.add("Pod P-1 fired")); count = \(recorder.entryCount)")
print("Add second entry: \(recorder.add("Crew manifest verified")); count = \(recorder.entryCount)")
print("Transcript before seal:\n\(recorder.transcript)")
recorder.seal()
print("Recorder sealed: \(recorder.isSealed)")
print("Try add after seal: \(recorder.add("This must not be written")); count = \(recorder.entryCount)")
print("Audit transcript:\n\(auditTranscript(of: recorder))")


// MARK: Finale · Integrity Code

let D = AlarmLevel.level(forTotalMass: A).rawValue
let integrityCode = "\(A)-\(B)-\(C)-\(D)"
print("\nINTEGRITY CODE: \(integrityCode)")


// MARK: Bonus

func comparePodIdentity(_ first: TeleportPod, _ second: TeleportPod) -> String {
    if first === second {
        return "same pod reference"
    }

    var occupantsMatch = false
    switch (first.occupant, second.occupant) {
    case (nil, nil):
        occupantsMatch = true
    case (let left?, let right?):
        occupantsMatch = left.name == right.name
            && left.deck.rawValue == right.deck.rawValue
            && left.oxygen == right.oxygen
    default:
        occupantsMatch = false
    }

    if first.id == second.id
        && first.chargeLevel == second.chargeLevel
        && occupantsMatch {
        return "different pods with equal contents"
    }

    return "different pods with different contents"
}

print("\n--- Bonus: ARC, deinit, and identity ---")
var retainedPod: TeleportPod?
do {
    let temporaryPod = TeleportPod(id: "TEMP", chargeLevel: 25)
    retainedPod = temporaryPod
    print("Inside do block: TEMP has two strong references")
}
print("After do block: TEMP is still alive because retainedPod still references it")
retainedPod = nil
print("After retainedPod = nil: the last strong reference is gone")

let identityA = TeleportPod(id: "ID-1", chargeLevel: 50)
let identityAlias = identityA
let identityEqualContents = TeleportPod(id: "ID-1", chargeLevel: 50)
print("Identity test 1: \(comparePodIdentity(identityA, identityAlias))")
print("Identity test 2: \(comparePodIdentity(identityA, identityEqualContents))")
